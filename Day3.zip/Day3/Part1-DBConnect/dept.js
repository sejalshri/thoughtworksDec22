"use strict";
exports.__esModule = true;
exports.Dept = void 0;
var Dept = /** @class */ (function () {
    function Dept(deptNo, dname, dloc) {
        this.deptNo = deptNo;
        this.dname = dname;
        this.dloc = dloc;
    }
    Dept.prototype.setName = function (name) {
        this.dname = name;
    };
    Dept.prototype.setdno = function (no) {
        this.deptNo = no;
    };
    Dept.prototype.setdloc = function (loc) {
        this.dloc = loc;
    };
    Dept.prototype.getName = function () {
        return this.dname;
    };
    Dept.prototype.getLoc = function () {
        return this.dloc;
    };
    Dept.prototype.getNo = function () {
        return this.deptNo;
    };
    return Dept;
}());
exports.Dept = Dept;
