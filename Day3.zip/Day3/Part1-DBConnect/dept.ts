export class Dept{
    private deptNo:number;
    private dname:String;
    private dloc:String;

    constructor(deptNo:number,dname:String,dloc:String){
        this.deptNo=deptNo;
        this.dname=dname;
        this.dloc=dloc;
    }

    public setName(name:string){
        this.dname=name;
    }
    public setdno(no:number){
        this.deptNo=no;
    }
    public setdloc(loc:String){
        this.dloc=loc;
    }

    public getName():String{
        return this.dname;
    }
    public getLoc():String{
        return this.dloc;
    }
    public getNo():number{
        return this.deptNo;
    }
    
}
