import { Dept } from "./dept"
import { DeptDAO } from "./deptDao"

const {  Client } = require("pg");

async function test(){
  var deptObj=new Dept(1,"one","Chennai");
  const deptdao = new DeptDAO()
/*  deptdao.create(deptObj)
  deptObj=new Dept(2,"twp","Chennai");
  deptdao.create(deptObj)
  deptObj=new Dept(3,"three","Chennai");
  deptdao.create(deptObj)
  deptObj=new Dept(2,"Training","Pnq");
  await deptdao.update(deptObj)
  await deptdao.delete(3) 
*/
  console.log(await deptdao.read())
}
test()
