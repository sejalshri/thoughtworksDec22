import { Dept } from "./dept";
const {  Client } = require("pg");
export class DeptDAO{
    
    private credentials = {
        user: "postgres",
        host: "localhost",
    // host: "postgres.cgx7wslwcmx7.us-east-1.rds.amazonaws.com",
        database: "postgres",
        password: "admin",
        port: 5432,
    };

 public async delete(deptno: number) {
     let client = new Client(this.credentials);
    await client.connect();
    var query="Delete from dept where deptno =" + deptno;
    console.log(query);
    const now = await client.query(query);
    await client.end();
}
public async update(deptObj: Dept) {
    let client = new Client(this.credentials);
   await client.connect();
   var query = "update dept set dname='"+ deptObj.getName() +"',loc='"+ deptObj.getLoc() + "' where deptno ="+ deptObj.getNo() 
   console.log("update "+ query);
   const now = await client.query(query);
   await client.end();
}
public async create(deptObj: Dept) {
    let client = new Client(this.credentials);
   await client.connect();
   var query="INSERT INTO dept values("+deptObj.getNo()+",'"+deptObj.getName()+"','"+deptObj.getLoc()+"')";
   console.log("insert " + query);
   const now = await client.query(query);
   await client.end();
}
// Option 2
public async read2(): Promise<Dept[]> {
    const client = new Client(this.credentials);
    let departments: Dept[] = [];
    client.connect();
    await client.query("SELECT * FROM dept").then(result => {
        departments=result.rows;
        });
    await client.end();
    return departments;
}

//Option1
public async read (): Promise<Dept[]> {
    const client = new Client(this.credentials);
    await client.connect();
    const query = `SELECT * FROM dept`;
    const result = await client.query(query);
    let allDepartments: Dept[] = [];
    result.rows.forEach((dept) => {
      allDepartments.push(new Dept(dept.deptno, dept.dname, dept.location));
    });
    await client.end();
    return allDepartments;
  }


}