function dtor(conversionrate) {
    console.log("in dtor, current conversionrate = " + conversionrate);
    // retaining value of x in return function
    return function (dl) {
        console.log("in retured function, current x = " + conversionrate);
        return dl * conversionrate;
    };
}
var x = dtor(80);
console.log(x(10));
console.log(x(20));
console.log(x(30));
console.log(x(40));
