function add(x, y) {
    return x + y;
}
function process(x:number,y:number , opn:(no1:number, no2:number)=>number){
  console.log(opn(x,y))
}
let sub = function (x, y) {  return x - y; };
process(10,50,add)
process(10,50,sub)
process(100,50,function (x, y) { return x / y;   })
