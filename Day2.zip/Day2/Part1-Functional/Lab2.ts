// Composition - whether to invoke morning or evening is decided by greet
/*
function greet(content:string){
  morning("Vaishali")
  console.log(content);
}
*/
// aggregation


function greet(gfn: (s:string)=>void,  content:string){
  gfn("StaticName")
  console.log(content)
}

function morning(s: string) {
  console.log("Good Morning, " + s);
}
 
function evening(s: string) {
  console.log("Good Evening, " + s);
}

//morning("Vaishali")
greet(morning, "How are things?")
greet((s:string)=>console.log("in line function"),"How are things?")
//greeter(printToConsole);

