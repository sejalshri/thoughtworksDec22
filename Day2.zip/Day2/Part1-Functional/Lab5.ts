function curry(targetFn: (str:string)=>void, existingArgs:string) {
    console.log("in curry main function")
    return function(str:string) {
      console.log("in return function : " + str)
      targetFn(str)

    }
  }
let tf = (str:string):void=>{console.log("in targetfunction " + str)}
curry(tf,"myarg")("a")
// Not correct impl of curry
function curry2(targetFn) {
    console.log("in curry main function");
    return function (str : string[]) {
        console.log("in return function : " + str);
        for(let s of str)
            targetFn(s);
    };
    }
var tf1 = function (str) { console.log("in targetfunction " + str); };
curry2(tf1)(["a", "b", "c"]);

function add(x: number): (y: number) => number {
    return function(y: number): number {
        return x + y;
    }
}
var res1: Function = add(1);
console.log(res1(400))

var res2: (y: number) => number = add(1);
console.log(res2(30))
var res3: number = add(1)(3);
console.log(res3)