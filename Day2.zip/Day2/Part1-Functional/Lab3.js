// Named function
function add(x, y) {
    return x + y;
}
function process(x, y, opn) {
    console.log(opn(x, y));
}
// Anonymous function
var sub = function (x, y) { return x - y; };
// invoke process to do +,-,*, / as operation
process(10, 50, add);
process(10, 50, sub);
process(100, 50, function (x, y) { return x / y; });
