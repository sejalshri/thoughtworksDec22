// Composition - whether to invoke morning or evening is decided by greet
/*
function greet(content:string){
  morning("Vaishali")
  console.log(content);
}
*/
// aggregation
function greet(gfn, content) {
    gfn("StaticName");
    console.log(content);
}
function morning(s) {
    console.log("Good Morning, " + s);
}
function evening(s) {
    console.log("Good Evening, " + s);
}
//morning("Vaishali")
greet(morning, "How are things?");
greet(function (s) { return console.log("in line function"); }, "How are things?");
//greeter(printToConsole);
function curry(fn) {
    return function (a) {
        return function (b) {
            return fn(a, b);
        };
    };
}
function sum(a, b) {
    return a + b;
}
var currySum = curry(sum);
console.log(currySum(100)(400));
console.log(currySum(110)(20)); // 30
