function curry(targetFn, existingArgs) {
    console.log("in curry main function");
    return function (str) {
        console.log("in return function : " + str);
        targetFn(str);
    };
}
var tf = function (str) { console.log("in targetfunction " + str); };
curry(tf, "myarg")("a");
// Not correct impl of curry
function curry2(targetFn) {
    console.log("in curry main function");
    return function (str) {
        console.log("in return function : " + str);
        for (var _i = 0, str_1 = str; _i < str_1.length; _i++) {
            var s = str_1[_i];
            targetFn(s);
        }
    };
}
var tf1 = function (str) { console.log("in targetfunction " + str); };
curry2(tf1)(["a", "b", "c"]);
function add(x) {
    return function (y) {
        return x + y;
    };
}
var res1 = add(1);
console.log(res1(400));
var res2 = add(1);
console.log(res2(30));
var res3 = add(1)(3);
console.log(res3);
