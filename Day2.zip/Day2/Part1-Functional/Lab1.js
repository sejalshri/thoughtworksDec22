// Named function
function add(x, y) {
    return x + y;
}
// Anonymous function
var myAdd = function (x, y) { return x + y; };
console.log(add(300, 500));
console.log(add("aaa", "bbb"));
console.log(add(true, true));
console.log(myAdd(10, 55));
// array as well enum
// pass emp
