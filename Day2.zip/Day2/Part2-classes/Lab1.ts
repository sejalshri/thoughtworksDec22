class Emp {
    private _empNo:number;
    private ename:string;
    private salary:number;

    
    constructor(empNo:number, ename:string, salary:number) {
        this._empNo = empNo;
        this.ename = ename;
        this.salary = salary;
    }
    // get/set syntax
    get empNo() {
        return this._empNo;
      }
    set empNo(value) {
        this._empNo = value;
      }
    // /method 
    public getName():string {
        return this.ename;
    }

    public getSalary():number {
        return this.salary;
    }

    public salaryIncrement(raise:number) {
        this.salary += this.salary * raise / 100;
    }

    public toString():void { 
        console.log("Employee Details");
        console.log(this.empNo, this.ename, this.salary);
    }
}

var e = new Emp(10,"AAA",1000)
e.empNo = 400
console.log(e.getName())
e.salaryIncrement(10)
e.toString()