import  { add, sub} from "./Helper"
console.log("Add returned " + add(100,33))
console.log("Sub returned " + sub(100,33))