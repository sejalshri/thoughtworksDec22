export function add(x:number, y:number)  {
    return x + y;
}
export function sub(x:number, y:number)  {
    return x - y;
}
