
function add(x:number, y:number)  {
    return x + y;
}
function sub(x:number, y:number)  {
    return x - y;
}
export let calc =[add ,sub];
export let calc1= {"add":add, "sub":sub}

