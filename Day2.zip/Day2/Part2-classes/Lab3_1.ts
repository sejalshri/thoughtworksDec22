import  { calc , calc1} from "./Helper1"
console.log("Add returned " + calc[0](100,33))
console.log("Sub returned " + calc[1](100,33))

console.log("Add returned " + calc1.add(100,33))
console.log("Sub returned " + calc1.sub(100,33))
