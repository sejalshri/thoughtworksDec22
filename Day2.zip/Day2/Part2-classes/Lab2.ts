class Vehicle {
    static count: number = 0;
    private engine: string;
    private category: string;
  
    constructor(engine: string, category: string) {
      this.engine = engine;
      this.category = category;
      Vehicle.count += 1;
    }
  }
  
  class Car extends Vehicle {
    private numberOfDoors: number;
  
    constructor(engine: string, category: string, numberOfDoors: number) {
      super(engine, category);
      this.numberOfDoors = numberOfDoors;
    }
  }
  
  class Bike extends Vehicle {
    private cc: number;
  
    constructor(engine: string, category: string, cc: number) {
      super(engine, category);
      this.cc = cc;
    }
  }
  
  let car1 = new Car("V8", "Sedan", 4);
  let bike1 = new Bike("Twin Cylinder", "Sports", 650);
  
  console.log(Vehicle.count);
  