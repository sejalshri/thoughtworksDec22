"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MyService = void 0;
class MyService {
    constructor() {
    }
    process(str) {
        return "Processed for " + str;
    }
}
exports.MyService = MyService;
