"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const MyService_1 = require("../MyService");
let myservice;
describe("FirstTestCase", () => {
    beforeEach(() => {
        console.log("before each invoked ");
        myservice = new MyService_1.MyService();
    });
    it("Check if defined", () => {
        expect(myservice.process("s")).toEqual("Processed for ss");
    });
});
