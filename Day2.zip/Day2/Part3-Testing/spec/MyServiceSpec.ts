import {MyService} from '../MyService'
let myservice: MyService;
describe("FirstTestCase",()=>{
    beforeEach(()=>{
        console.log("before each invoked ")
        myservice = new MyService()
    });
    it("Check if defined",()=>{
        expect(myservice.process("s")).toEqual("Processed for ss")
    })
})
