export class MyService{
    constructor(){

    }
    public process(str:string){
        return "Processed for "+str;
    }
}