// Global Section
let letstr="let in global"
var varstr="var in global"

function simple(){
    // Scope - Function
   let letstr1="letinsimple"
   let varstr1="varinsimple"
    console.log("current value of letstr in simple : "+ letstr)
    console.log("current value of varstr in simple : "+ varstr)
}
function simple1(){
    console.log("current value of letstr in simple1 : "+ letstr)
    console.log("current value of varstr in simple1 : "+ varstr)
}
console.log("----------Global Section -----------")
console.log("letstr = "+ letstr)
console.log("varstr = "+ varstr)
simple()
simple1()
console.log("----------Global Section after simple & simple1 -----------")
console.log("letstr = "+ letstr)
console.log("varstr = "+ varstr)



