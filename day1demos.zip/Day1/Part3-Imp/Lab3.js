// Global Section
var letstr = "let in global";
var varstr = "var in global";
var constr = "const in global";
console.log("----------Global Section -----------");
console.log("letstr = " + letstr);
console.log("varstr = " + varstr);
console.log("constr = " + constr);
letstr = "New Let in Global";
varstr = "New var in Global";
//constr - can't be assigned
//constr = "New Const in Global"
console.log("----------Global Section after simple & simple1 -----------");
console.log("letstr = " + letstr);
console.log("varstr = " + varstr);
console.log("constr = " + constr);
