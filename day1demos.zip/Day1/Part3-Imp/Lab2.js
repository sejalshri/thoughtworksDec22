// Global Section
var letstr = "let in global";
var varstr = "var in global";
function simple1() {
    {
        var letstr1 = "letinsimple1functionscope";
        var varstr1 = "varinsimple1functionscope";
        console.log("---------------In Simple1 Block -------------");
        console.log("current value of letstr in simple1 : " + letstr);
        console.log("current value of varstr in simple1 : " + varstr);
        console.log("current value of letstr1 in simple1 : " + letstr1);
        console.log("current value of varstr1 in simple1 : " + varstr1);
    }
    console.log("---------------In Simple1 Function -------------");
    console.log("current value of letstr in simple1 : " + letstr);
    console.log("current value of varstr in simple1 : " + varstr);
    console.log("current value of letstr1 in simple1 : " + letstr1);
    console.log("current value of varstr1 in simple1 : " + varstr1);
}
console.log("----------Global Section -----------");
console.log("letstr = " + letstr);
console.log("varstr = " + varstr);
simple1();
console.log("----------Global Section after simple & simple1 -----------");
console.log("letstr = " + letstr);
console.log("varstr = " + varstr);
