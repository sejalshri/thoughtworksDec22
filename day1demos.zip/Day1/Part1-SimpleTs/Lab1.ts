let x:number = 30
let y = 300 // type is inferred
let z:String ="aaa"
z = "Fands"
console.log(z)