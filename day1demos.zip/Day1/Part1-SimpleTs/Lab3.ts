class Emp {
    empno: number;
    ename: string
    salary:number

    public incrSalary(percent:number) {
        this.salary+=this.salary*percent/100
      }

  }
const e1 = new Emp();
e1.empno = 1
e1.ename="Aaaaa"
e1.salary = 10000
console.log(e1)
e1.incrSalary(20)
console.log(e1)

