const names:string[] = [];
names.push("aaa")
names.push("bbb")
names.push("ccc")

console.log(names)

