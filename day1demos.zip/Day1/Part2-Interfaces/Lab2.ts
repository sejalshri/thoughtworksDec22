interface Connection{
    open():void;
    close():void;
}

class Oracle implements Connection{
    open():void{
        console.log("oracle connection opened");
    }
    close():void{
        console.log("oracle connection closed");
    }
}
class Mysql implements Connection{
    open():void{
        console.log("mysql connection opened");
    }
    close():void{
        console.log("mysql connection closed");
    }
}


let x = Math.floor(Math.random()*10)
let interface_connection:Connection
console.log("Random = " + x)
if(x%2 == 0){
    interface_connection = new Oracle()
}else{
    interface_connection = new  Mysql()
}

interface_connection.open()
interface_connection.close()
