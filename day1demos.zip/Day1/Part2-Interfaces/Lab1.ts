interface Show {
     print():void;
}
class Emp implements Show{
    print(): void {
        console.log("Emp implementing print method of Show interface")
    }
}
var e1 = new Emp()
e1.print()
var show:Show = e1
show.print()